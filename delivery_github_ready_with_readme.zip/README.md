# 🚚 Delivery Tracker Simulation

This project simulates a delivery truck moving from **Tesla HQ in Austin, TX** to **2502 Bentley Dr, Palm Harbor, FL** using real driving roads.

### Features
- Start: Tesla HQ, Austin, TX (30.224089, -97.614470)  
- Destination: 2502 Bentley Dr, Palm Harbor, FL (28.0907990, -82.7311860)  
- Smooth animated truck moving along the calculated route  
- Live road routing via **Leaflet Routing Machine (OSRM)**  
- Distance, ETA, and speed controls  
- Works in any modern web browser  

### How to Use
1. Open the page in your browser.  
2. Click **Start Online Route** to fetch the real driving path.  
3. Adjust the speed slider to control truck movement.  
4. Share the GitHub Pages link with your client – they’ll see the simulation live.  

### Live Demo
Once published on GitHub Pages, your site will be available at:

```
https://yourusername.github.io/delivery-tracker/
```
